package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class hubspotLandingPage {

	public WebDriver driver;

	private By ValidatingHubSpotWebsite = By.xpath("//*[@id='hsg-nav__logo-desktop']");

	private By allowCookies = By.id("hs-eu-confirmation-button");
	
	private By ScrolltoCMSSection = By.xpath("(//*[@class='home-products-feature__card--list'])[1]");

	
	

	public hubspotLandingPage(WebDriver driver) {

		this.driver = driver;

	}

	public WebElement ValidatingHubSpotWebsite() {
		return driver.findElement(ValidatingHubSpotWebsite);
	}

	public WebElement allowCookies() {
		return driver.findElement(allowCookies);
	}
	
	public WebElement ScrolltoCMSSection() {
		return driver.findElement(ScrolltoCMSSection);
	}
	

}

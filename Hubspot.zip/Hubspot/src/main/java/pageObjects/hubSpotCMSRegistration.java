package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class hubSpotCMSRegistration {

	public WebDriver driver;

	private By PopularFeatures = By.xpath("(//*[@class='home-products-feature__card--list'])[1]");

	private By CLickonGetStartedButton = By.xpath("(//*[@class='cta--primary cta--medium homepage-cms'])[1]");

	private By PremiumEditionsFeatures = By.xpath("(//*[@class='products-pricing-cards__product-features'])[2]");

	private By ClickonGetDemoButton = By.xpath("//*[@class='cta--primary cta--large cms-hero-1']");

	private By FirstName = By.xpath("(//*[@class='hs-input'])[1]");

	private By LastName = By.xpath("(//*[@class='hs-input'])[2]");

	private By EmailID = By.xpath("(//*[@class='hs-input'])[3]");

	private By PhoneNumber = By.xpath("(//*[@name='phone'])");

	private By CompanyName = By.xpath("(//*[@name='company'])");

	private By WebsiteURL = By.xpath("(//*[@name='website'])");

	private By SelectEmployeeSize = By.xpath("(//*[@name='employees__c'])");

	private By SubscribeCheckbox = By.xpath("(//*[@class='hs-input'])[6]");

	private By ClickFreeDemoSubmitButton = By.xpath("(//*[@class='hs-button primary large'])[1]");

	public hubSpotCMSRegistration(WebDriver driver) {

		this.driver = driver;

	}

	public WebElement PopularFeatures() {
		return driver.findElement(PopularFeatures);
	}

	public WebElement CLickonGetStartedButton() {
		return driver.findElement(CLickonGetStartedButton);
	}

	public WebElement PremiumEditionsFeatures() {
		return driver.findElement(PremiumEditionsFeatures);
	}

	public WebElement ClickonGetDemoButton() {
		return driver.findElement(ClickonGetDemoButton);
	}

	public WebElement FirstName() {
		return driver.findElement(FirstName);
	}

	public WebElement LastName() {
		return driver.findElement(LastName);
	}

	public WebElement EmailID() {
		return driver.findElement(EmailID);
	}

	public WebElement PhoneNumber() {
		return driver.findElement(PhoneNumber);
	}

	public WebElement CompanyName() {
		return driver.findElement(CompanyName);
	}

	public WebElement WebsiteURL() {
		return driver.findElement(WebsiteURL);
	}

	public WebElement SelectEmployeeSize() {
		return driver.findElement(SelectEmployeeSize);
	}

	public WebElement SubscribeCheckbox() {
		return driver.findElement(SubscribeCheckbox);
	}

	public WebElement ClickFreeDemoSubmitButton() {
		return driver.findElement(ClickFreeDemoSubmitButton);
	}
}

package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class hubspotLogin {

	public WebDriver driver;

	private By ClickLoginLink = By.xpath("//*[@class='homepage-nav-login']");

	private By UserName = By.id("username");

	private By Password = By.id("password");

	private By ClickLoginButton = By.id("loginBtn");

	private By ClickSalesDropdown = By.id("nav-primary-sales-branch");

	private By SeectDealsSection = By.id("nav-secondary-deals");

	private By CreateDeals = By.xpath(
			"//*[@class='uiButton private-button private-button--primary private-button--default add-obj private-button--non-link']");

	private By EnterDealName = By.id("UIFormControl-24");

	private By SelectPipeline = By.xpath("(//*[@class='private-dropdown__button-label uiDropdown__buttonLabel'])[9]");

	private By SelectAppointment = By
			.xpath("(//*[@class='private-dropdown__button-label uiDropdown__buttonLabel'])[10]");

	private By EnterAmount = By.xpath("(//*[@class='form-control private-form__control'])[1]");

	private By SelectBusinessType = By
			.xpath("(//*[@class='private-dropdown__button-label uiDropdown__buttonLabel'])[11]");

	private By SearchCompanyType = By
			.xpath("(//*[@class='private-dropdown__button-label uiDropdown__buttonLabel'])[13]");

	private By EnterCompany = By
			.xpath("(//*[@class='form-control private-form__control private-search-control__input'])[3]");

	private By AddLineIteam = By.xpath("(//*[@class='private-dropdown__button-label uiDropdown__buttonLabel'])[14]");

	private By AddQuantity = By.xpath("(//*[@class='form-control private-form__control uiNumberInput m-right-4'])[1]");

	private By ClickCreatButton = By
			.xpath("(//*[@class='private-loading-button__content private-button--internal-spacing'])[1]");

	public hubspotLogin(WebDriver driver) {

		this.driver = driver;

	}

	public WebElement ClickLoginLink() {
		return driver.findElement(ClickLoginLink);
	}

	public WebElement UserName() {
		return driver.findElement(UserName);
	}

	public WebElement Password() {
		return driver.findElement(Password);
	}

	public WebElement ClickLoginButton() {
		return driver.findElement(ClickLoginButton);
	}

	public WebElement ClickSalesDropdown() {
		return driver.findElement(ClickSalesDropdown);
	}

	public WebElement SeectDealsSection() {
		return driver.findElement(SeectDealsSection);
	}

	public WebElement CreateDeals() {
		return driver.findElement(CreateDeals);
	}

	public WebElement EnterDealName() {
		return driver.findElement(EnterDealName);
	}

	public WebElement SelectPipeline() {
		return driver.findElement(SelectPipeline);
	}

	public WebElement SelectAppointment() {
		return driver.findElement(SelectAppointment);
	}

	public WebElement EnterAmount() {
		return driver.findElement(EnterAmount);
	}

	public WebElement SelectBusinessType() {
		return driver.findElement(SelectBusinessType);
	}

	public WebElement SearchCompanyType() {
		return driver.findElement(SearchCompanyType);
	}

	public WebElement EnterCompany() {
		return driver.findElement(EnterCompany);
	}

	public WebElement AddLineIteam() {
		return driver.findElement(AddLineIteam);
	}

	public WebElement AddQuantity() {
		return driver.findElement(AddQuantity);
	}

	public WebElement ClickCreatButton() {
		return driver.findElement(ClickCreatButton);
	}

}

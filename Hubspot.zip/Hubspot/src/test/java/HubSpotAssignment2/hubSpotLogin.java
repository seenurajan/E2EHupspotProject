package HubSpotAssignment2;

import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pageObjects.hubspotLandingPage;
import pageObjects.hubspotLogin;
import pageObjects.hubSpotCMSRegistration;
import resources.base;

public class hubSpotLogin extends base {
	public WebDriver driver;

	public static Logger log = LogManager.getLogger(base.class.getName());

	@BeforeTest
	public void initialize() throws IOException {

		driver = initializeDriver();

	}

	@Test()

	public void basePageNavigation() throws IOException, InterruptedException {

		// HubSpot Login Page

		driver.get(prop.getProperty("Loginurl"));

		hubspotLogin hubSpotLogin = new hubspotLogin(driver);

		Thread.sleep(6000);

		// Clicking Login Link
		hubSpotLogin.ClickLoginLink().click();

		// Enter User name
		hubSpotLogin.UserName().sendKeys(LoginUserdada.getProperty("UserName"));

		// Enter Password
		hubSpotLogin.Password().sendKeys(LoginUserdada.getProperty("Password"));

		// Clicking Login Button
		hubSpotLogin.ClickLoginButton().click();

		// Clicking SalesDropdown Button
		hubSpotLogin.ClickSalesDropdown().click();

		// Selecting Deals section
		hubSpotLogin.SeectDealsSection().click();

		// Clicking create Deal button
		hubSpotLogin.CreateDeals().click();

		//Entering deal name
		hubSpotLogin.EnterDealName().sendKeys(LoginUserdada.getProperty("DealName"));

		// Selecting pipeline
		hubSpotLogin.SelectPipeline().click();

		Select employeesize = new Select(hubSpotLogin.SelectPipeline());
		employeesize.selectByIndex(2);
		Thread.sleep(4000);

		// Entering the amount
		hubSpotLogin.EnterAmount().sendKeys(LoginUserdada.getProperty("Amount"));

		hubSpotLogin.SelectBusinessType().click();

		Select SelectBusinessType = new Select(hubSpotLogin.SelectBusinessType());
		SelectBusinessType.selectByIndex(3);
		Thread.sleep(4000);

		//Entering company name
		hubSpotLogin.SearchCompanyType().sendKeys(LoginUserdada.getProperty("Companyname"));

		//Searching company name
		hubSpotLogin.EnterCompany().sendKeys(LoginUserdada.getProperty("EnterCompany"));

		// Adding in line iteam
		hubSpotLogin.AddLineIteam().click();

		// Adding Quantity
		hubSpotLogin.AddQuantity().click();

		// Clicking Create Deal Button 
		hubSpotLogin.ClickCreatButton().click();

	}

	@AfterTest
	public void teardown() {

		driver.manage().deleteAllCookies();
		driver.close();

	}

}

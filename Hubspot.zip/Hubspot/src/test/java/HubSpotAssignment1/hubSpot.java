package HubSpotAssignment1;

import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pageObjects.hubspotLandingPage;
import pageObjects.hubSpotCMSRegistration;
import resources.base;

public class hubSpot extends base {
	public WebDriver driver;

	public static Logger log = LogManager.getLogger(base.class.getName());

	@BeforeTest
	public void initialize() throws IOException {

		driver = initializeDriver();

	}

	@Test()

	public void basePageNavigation() throws IOException, InterruptedException {

		// HubSpot landing URL

		driver.get(prop.getProperty("url"));

		hubspotLandingPage hubSpotcookies = new hubspotLandingPage(driver);

		// HubSpot handling cookies and verifying the hubspot website

		hubSpotcookies.allowCookies().click();
		hubSpotcookies.ValidatingHubSpotWebsite().click();

		// Scroll down to CMS section in hubspot page

		WebElement ScrollToCMS = hubSpotcookies.ScrolltoCMSSection();
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ScrollToCMS);
		Thread.sleep(500);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,550)", "");
		Thread.sleep(3000);

		// CMS Premium features and Registering to demo account

		hubSpotCMSRegistration CMSDemoRegestrationPage = new hubSpotCMSRegistration(driver);
		CMSDemoRegestrationPage.PopularFeatures().getText();

		System.out.println(CMSDemoRegestrationPage);

		// Verifying the Premium Editions Features

		CMSDemoRegestrationPage.PopularFeatures();

		// Clicking on start button

		CMSDemoRegestrationPage.CLickonGetStartedButton().click();

		// Clicking on Get Demo button

		CMSDemoRegestrationPage.ClickonGetDemoButton().click();

		// CMS Demo account Registration

		CMSDemoRegestrationPage.FirstName().sendKeys(Userdada.getProperty("FirstName"));

		CMSDemoRegestrationPage.LastName().sendKeys(Userdada.getProperty("LastName"));

		CMSDemoRegestrationPage.EmailID().sendKeys(Userdada.getProperty("EmailID"));

		CMSDemoRegestrationPage.PhoneNumber().sendKeys(Userdada.getProperty("PhoneNumber"));

		CMSDemoRegestrationPage.CompanyName().sendKeys(Userdada.getProperty("CompanyName"));

		CMSDemoRegestrationPage.WebsiteURL().sendKeys(Userdada.getProperty("Website"));

		// CMS Selecting employee size

		CMSDemoRegestrationPage.SelectEmployeeSize().click();

		Select employeesize = new Select(CMSDemoRegestrationPage.SelectEmployeeSize());
		employeesize.selectByIndex(3);

		CMSDemoRegestrationPage.SubscribeCheckbox().click();

		CMSDemoRegestrationPage.ClickFreeDemoSubmitButton().click();

	}

	@AfterTest
	public void teardown() {

		driver.manage().deleteAllCookies();
		driver.close();

	}

}
